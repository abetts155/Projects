#include <stdio.h>

int 
main (void)
{
  printf("HELLO!");
  return 0;
}

