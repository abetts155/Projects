#!/bin/bash
export IDIR=$PWD
tar -xzf simplesim-3.0.tgz
echo "Building SimpleScalar tools"
pushd simplesim-3.0 && make
popd
tar -xzf simpleutils-990811.tar.gz
tar -xzf simpletools-2v0.tar.gz
echo "Building SimpleScalar binutils"
pushd simpleutils-990811
./configure --host=i386-*-linux --target=sslittle-na-sstrix --with-gnu-as --with-gnu-ld --prefix=$IDIR
make all install
popd
export PATH=$PATH:$IDIR/sslittle-na-sstrix/bin
mv ar $IDIR/sslittle-na-sstrix/bin
mv ranlib $IDIR/sslittle-na-sstrix/bin
chmod +x $IDIR/sslittle-na-sstrix/bin/ar
chmod +x $IDIR/sslittle-na-sstrix/bin/ranlib
tar -xzf gcc-2.7.2.3.tar.gz
echo "Building SimpleScalar GCC"
pushd gcc-2.7.2.3
./configure --host=i386-*-linux --target=sslittle-na-sstrix --with-gnu-as --with-gnu-ld --prefix=$IDIR --enable-languages=c
make
make install
echo "Making symbolic links to SimpleScalar binaries"
ln -s $IDIR/simplesim-3.0/sim-bpred $IDIR/bin/sim-bpred
ln -s $IDIR/simplesim-3.0/sim-cache $IDIR/bin/sim-cache
ln -s $IDIR/simplesim-3.0/sim-eio $IDIR/bin/sim-eio
ln -s $IDIR/simplesim-3.0/sim-fast $IDIR/bin/sim-fast
ln -s $IDIR/simplesim-3.0/sim-outorder $IDIR/bin/sim-outorder
ln -s $IDIR/simplesim-3.0/sim-profile $IDIR/bin/sim-profile
ln -s $IDIR/simplesim-3.0/sim-safe $IDIR/bin/sim-safe
echo "Done!"
